
# -*- coding: utf-8 -*-
#####################################################################
# SIRO48-PTseq Quantification Test Script
#####################################################################
# 测试定量功能：从POS11 Col1加载定量管，运行定量，放回原位，弹窗报浓度
# 使用前确保POS11 Col1已放置含有样本的定量管
#####################################################################

from library import *
spxsiro = globals().get("library")
set_siro(spxsiro)

# ===== 配置参数 =====
# 定量管位置
quantification_tube_loc = ['M2_POS11', 1]

# 样本定量阶段，只支持PCR，Extract，DNB
sample_stage = 'PCR'

# 定量管数量（1列=8个管）
sample_num = 8
col_num = 1

# ===== 浓度获取函数 =====
def get_concentration_modified(pos):
    try:
        spx_concentration = find_sampling_concentration(pos[0], pos[2], pos[1])
        if spx_concentration is None:
            print(f"  [WARNING] No concentration data at {pos}")
            return 0.0
        return spx_concentration.Consistence
    except Exception as e:
        print(f"  [WARNING] get_concentration error at {pos}: {e}")
        return 0.0

# ===== 执行定量 =====
concentration_list = []

# 单个定量管位置，板列行
quantification_tubes = [(quantification_tube_loc[0], quantification_tube_loc[1] + i // 8, 1 + i % 8) for i in range(sample_num)]

# 加载定量管 → 运行定量 → 放回原位
for i in range(col_num):
    p8_load_quantification_tube({"Position": quantification_tube_loc[0], "Row": 1, "Col": quantification_tube_loc[1] + i, "Tips": 8})
    spx_quantity_result = quantity_run_sample({"Name": "", "SampleType": "dsDNA_HS", "ProductType": sample_stage, "StandardToSampleRatio": 5, "DilutionRatio": 1, "Label": "", "DilutionAssessment": 60})
    cur_concentration_list = [get_concentration_modified((quantification_tube_loc[0], quantification_tube_loc[1] + i, j)) for j in range(1, 9)]
    concentration_list += cur_concentration_list
    p8_unload_quantification_tube({"Position": quantification_tube_loc[0], "Row": 1, "Col": quantification_tube_loc[1] + i, "Tips": 8})

# ===== 弹窗显示浓度结果 =====
# 构建浓度报告字符串
report_lines = []
for i, conc in enumerate(concentration_list):
    well_col = quantification_tube_loc[1] + i // 8
    well_row = 1 + i % 8
    row_letter = chr(ord('A') + well_row - 1)
    report_lines.append(f"  {row_letter}{well_col}: {conc:.2f} ng/uL")

concentration_report = "Quantification Results (POS11 Col1):\n" + "\n".join(report_lines)
print(concentration_report)

# 弹窗提示
try:
    popup({"Content": concentration_report})
except:
    pass

# ===== 输出定量数据 =====
output_quantitative_data({"ProductType": sample_stage, "FilePath": r"D:\data\PTseq_Quantification_Test.xlsx"})
